# Club JM - Bot Telegram & Web App

Monorepo complet avec Backend (FastAPI + Aiogram) et Frontend (React).

## 📁 Structure

```
clubjm/
├── backend/          # FastAPI + Aiogram Bot
│   ├── app/
│   │   ├── models.py        # SQLAlchemy models
│   │   ├── schemas.py       # Pydantic schemas
│   │   ├── crud.py          # Database operations
│   │   ├── auth.py          # Telegram auth
│   │   ├── api.py           # FastAPI endpoints
│   │   ├── bot.py           # Aiogram bot
│   │   ├── database.py      # DB connection
│   │   └── config.py        # Configuration
│   ├── main.py              # Entry point
│   ├── requirements.txt
│   ├── Dockerfile
│   └── .env.example
├── frontend/         # React + Vite
│   ├── src/
│   ├── public/
│   ├── package.json
│   └── .env.example
├── .gitignore
└── README.md

```

## 🚀 Quick Start

### Backend (Koyeb)

```bash
cd backend
pip install -r requirements.txt
cp .env.example .env
# Configurer .env
python main.py
```

### Frontend (Vercel)

```bash
cd frontend
npm install
cp .env.example .env.local
# Configurer .env.local avec VITE_API_BASE_URL
npm run dev
```

## 🔧 Configuration

### Backend (.env)

```env
# Database (Neon)
DATABASE_URL=postgresql://...

# Telegram
BOT_TOKEN=YOUR_BOT_TOKEN
TELEGRAM_CHANNEL_ID=-1002632653839

# JWT
JWT_SECRET=your-secret-key-min-32-chars

# API
API_PORT=8000
API_ORIGIN=https://clubjm.vercel.app
```

### Frontend (.env.local)

```env
VITE_API_BASE_URL=https://your-backend.koyeb.app
VITE_BOT_TOKEN=YOUR_BOT_TOKEN
```

## 📚 Documentation

- Backend: `backend/README.md`
- Frontend: `frontend/README.md`
- Deployment: `backend/DEPLOYMENT_CHECKLIST.md`
- Installation: `backend/INSTALLATION.md`

## 🎯 Fonctionnalités

- ✅ Bot Telegram (`/start`, `/ref`, `/help`, `/about`)
- ✅ Mini Web App React intégrée
- ✅ Système de classement (Starter → Master)
- ✅ Parrainage avec referral codes
- ✅ Gestion des coupons
- ✅ Panel admin complet
- ✅ Database PostgreSQL (Neon)
- ✅ JWT Authentication

## 🛠️ Tech Stack

**Backend:**
- FastAPI (Python)
- Aiogram 3 (Telegram Bot)
- SQLAlchemy (ORM)
- PostgreSQL (Neon)

**Frontend:**
- React 19
- TypeScript
- Vite
- Tailwind CSS

## 📖 Guides d'installation

Voir les fichiers dans `backend/`:
- `QUICKSTART.md` - 5 minutes
- `INSTALLATION.md` - Détaillé
- `DEPLOYMENT_CHECKLIST.md` - Production
- `FRONTEND_SETUP.md` - Intégration React

## 🚢 Déploiement

1. **Backend sur Koyeb:**
   ```bash
   git push origin main
   ```
   Configurer dans Koyeb: `python main.py`

2. **Frontend sur Vercel:**
   - Connecter repo
   - Root: `frontend/`
   - Build: `npm run build`
   - Output: `dist`

## 📞 Support

- Support bot: t.me/JMDAVEKKKK
- Channel: https://t.me/+gpImJ4tj2BUxMzE0
