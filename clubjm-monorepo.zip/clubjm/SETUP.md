# Setup - Club JM Bot & Web App

## 🚀 Commencer

### 1. Cloner le repo
```bash
git clone https://github.com/YOUR_USERNAME/clubjm.git
cd clubjm
```

### 2. Configuration Backend (Koyeb)

```bash
cd backend

# Créer .env depuis .env.example
cp .env.example .env

# Éditer .env avec vos variables:
# - DATABASE_URL (Neon)
# - BOT_TOKEN (Telegram)
# - JWT_SECRET (openssl rand -base64 32)
nano .env

# Installer dépendances
pip install -r requirements.txt

# Tester localement
python main.py
```

### 3. Configuration Frontend (Vercel)

```bash
cd ../frontend

# Créer .env.local depuis .env.example
cp .env.example .env.local

# Éditer .env.local:
# VITE_API_BASE_URL=https://votre-backend.koyeb.app
nano .env.local

# Installer et tester
npm install
npm run dev
```

### 4. Déployer Backend sur Koyeb

1. Créer compte Koyeb.com
2. New App → GitHub repo
3. Select: clubjm repo, Branch: main, Root: backend/
4. Build: `pip install -r requirements.txt`
5. Run: `python main.py`
6. Environment Variables → Ajouter tous depuis backend/.env
7. Deploy

### 5. Déployer Frontend sur Vercel

1. Aller sur vercel.com
2. Import project → clubjm GitHub repo
3. Framework: Vite
4. Root directory: `frontend/`
5. Build: `npm run build`
6. Output: `dist`
7. Environment → Ajouter VITE_API_BASE_URL
8. Deploy

### 6. Tester

1. Visiter bot Telegram: @YOUR_BOT
2. `/start`
3. Cliquer "Ouvrir App"
4. Vérifier connexion API

## 📚 Documentation

- Backend: `backend/QUICKSTART.md`
- Deployment: `backend/DEPLOYMENT_CHECKLIST.md`
- Installation: `backend/INSTALLATION.md`

## 🔗 Liens Utiles

- [Neon Docs](https://neon.tech)
- [Koyeb Docs](https://koyeb.com/docs)
- [Vercel Docs](https://vercel.com/docs)
- [Aiogram Docs](https://docs.aiogram.dev)
- [FastAPI Docs](https://fastapi.tiangolo.com)

## 🐛 Troubleshooting

**Bot ne répond pas:**
- Vérifier BOT_TOKEN dans backend/.env
- Vérifier logs Koyeb
- Tester `/start` command

**API erreur CORS:**
- Vérifier API_ORIGIN dans backend/.env
- Doit égaler votre URL Vercel

**Erreur Database:**
- Vérifier DATABASE_URL
- Tester connexion: `psql $DATABASE_URL`
- Vérifier SSL: `?sslmode=require`

## 📞 Support

- Support: t.me/JMDAVEKKKK
- Channel: https://t.me/+gpImJ4tj2BUxMzE0
